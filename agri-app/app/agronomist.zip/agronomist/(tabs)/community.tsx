import { View, Text } from 'react-native'
import React from 'react'

export default function Community() {
  return (
    <View>
      <Text>Community</Text>
    </View>
  )
}