// import React, { useState, useEffect } from 'react';
// import { StyleSheet, Text, View, TouchableOpacity, ScrollView, TextInput, Image, Alert, Platform } from 'react-native';
// import { useRouter } from 'expo-router';
// import { Ionicons } from '@expo/vector-icons';
// import axios from 'axios';
// import { useTranslation } from 'react-i18next';
// import * as Localization from 'expo-localization';
// import i18n from 'i18next';
// import { initReactI18next } from 'react-i18next';
// import * as ImagePicker from 'expo-image-picker';

// import cattleImage from '../../../assets/images/cattlediagnose.jpg';
// import cropImage from '../../../assets/images/cropdiagnose.jpg';

// const primaryGreen = '#81C784';
// const secondaryYellow = '#FFF59D';
// const primaryBlue = '#64B5F6';
// const white = '#FFFFFF';
// const darkGray = '#333';
// const inputBackgroundColor = '#F5F5F5';
// const inputBorderColor = '#E0E0E0';
// const lightBlueBackground = '#D1E9FF ';

// i18n.use(initReactI18next).init({
//   resources: {
//     en: {
//       translation: {
//         diagnosisScreen: {
//           whatToDiagnose: 'What do you want to diagnose?',
//           cattle: 'Cattle',
//           crop: 'Crop',
//           diagnoseVia: 'Diagnose {{category}} via:',
//           enterSymptoms: 'Enter Symptoms',
//           uploadCaptureImage: 'Upload/Capture Image',
//           backToCategory: 'Back to Category',
//           selectSymptoms: 'Select {{category}} Symptoms',
//           otherSymptoms: 'Other Symptoms',
//           enterOtherSymptoms: 'Enter other {{category}} symptoms',
//           diagnoseButton: 'Diagnose',
//           diagnosing: 'Diagnosing...',
//           back: 'Back',
//           diagnosisResult: 'Diagnosis Result',
//           predictedDisease: 'Predicted Disease: {{disease}}',
//           diagnosisFailed: 'Diagnosis failed. Please try again.',
//         },
//         error: 'Error',
//       },
//     },
//   },
//   lng: Localization.locale,
//   fallbackLng: 'en',
//   interpolation: {
//     escapeValue: false,
//   },
// });

// const DiagnosisScreen = () => {
//   const router = useRouter();
//   const [selectedCategory, setSelectedCategory] = useState<'cattle' | 'crop' | 'cattle_symptoms' | 'crop_symptoms' | null>(null);
//   const [selectedCattleSymptoms, setSelectedCattleSymptoms] = useState<string[]>([]);
//   const [selectedCropSymptoms, setSelectedCropSymptoms] = useState<string[]>([]);
//   const [otherCattleSymptom, setOtherCattleSymptom] = useState('');
//   const [otherCropSymptom, setOtherCropSymptom] = useState('');
//   const [predictionResult, setPredictionResult] = useState('');
//   const [isDiagnosing, setIsDiagnosing] = useState(false);
//   const { t } = useTranslation();

//   const cattleSymptomsList = ['Loss of appetite', 'Fever', 'Coughing', 'Skin lesions', 'Lameness'];
//   const cropSymptomsList = ['Wilting', 'Yellowing leaves', 'Stunted growth', 'Spots on leaves', 'Root rot'];

//   const handleCategorySelect = (category: 'cattle' | 'crop') => {
//     setSelectedCategory(category);
//     setPredictionResult('');
//   };

//   const toggleCattleSymptom = (symptom: string) => {
//     setSelectedCattleSymptoms((prev) => prev.includes(symptom) ? prev.filter(s => s !== symptom) : [...prev, symptom]);
//   };

//   const toggleCropSymptom = (symptom: string) => {
//     setSelectedCropSymptoms((prev) => prev.includes(symptom) ? prev.filter(s => s !== symptom) : [...prev, symptom]);
//   };

//   const handleSubmitSymptoms = async () => {
//     let allSymptoms: string[] = [];
  
//     if (selectedCategory === 'cattle_symptoms') {
//       allSymptoms = [...selectedCattleSymptoms];
//       if (otherCattleSymptom.trim() !== '') {
//         allSymptoms.push(otherCattleSymptom.trim());
//       }
  
//       try {
//         setIsDiagnosing(true);
//         setPredictionResult('');
  
//         const backendUrl = 'http://192.168.29.5:5000/predict'; // Same as image endpoint but POST body differs
  
//         const response = await axios.post(backendUrl, {
//           symptoms: allSymptoms.join(', '), // 👈 sending a plain string, as Flask expects
//         });
  
//         const { disease } = response.data;
//         setPredictionResult(t('diagnosisScreen.predictedDisease', { disease }));
//         Alert.alert(t('diagnosisScreen.diagnosisResult'), t('diagnosisScreen.predictedDisease', { disease }));
//       } catch (error) {
//         console.error('Symptom diagnosis error:', error);
//         Alert.alert(t('error'), t('diagnosisScreen.diagnosisFailed'));
//       } finally {
//         setIsDiagnosing(false);
//       }
//     } else if (selectedCategory === 'crop_symptoms') {
//       allSymptoms = [...selectedCropSymptoms];
//       if (otherCropSymptom.trim() !== '') {
//         allSymptoms.push(otherCropSymptom.trim());
//       }
  
//       Alert.alert('Crop Diagnosis', 'Crop symptom-based diagnosis is not yet implemented.');
//     }
//   };
  
  

//   const navigateToImageDiagnosis = async () => {
//     try {
//       const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
//       if (status !== 'granted') {
//         Alert.alert('Permission denied', 'Camera roll permissions are required.');
//         return;
//       }

//       const result = await ImagePicker.launchImageLibraryAsync({
//         mediaTypes: ImagePicker.MediaTypeOptions.Images,
//         allowsEditing: true,
//         quality: 1,
//       });

//       if (!result.canceled && result.assets.length > 0) {
//         const image = result.assets[0];
//         const formData = new FormData();

//         formData.append('image', {
//           uri: image.uri,
//           name: 'diagnosis.jpg',
//           type: 'image/jpeg',
//         } as any);

//         const backendUrl = 'http://192.168.29.5:5001/predict'; 

//         setIsDiagnosing(true);
//         setPredictionResult('');

//         const response = await axios.post(`${backendUrl}`, formData, {
//           headers: {
//             'Content-Type': 'multipart/form-data',
//           },
//         });

//         console.log('Response Data:', response.data); // Inspect the response

//         const { disease } = response.data; // Assuming the backend returns 'disease'
//         setPredictionResult(t('diagnosisScreen.predictedDisease', { disease }));
//         Alert.alert(t('diagnosisScreen.diagnosisResult'), t('diagnosisScreen.predictedDisease', { disease }));
//       }
//     } catch (error) {
//       console.error('Image diagnosis failed:', error);
//       Alert.alert(t('error'), t('diagnosisScreen.diagnosisFailed'));
//     } finally {
//       setIsDiagnosing(false);
//     }
//   };

//   const renderCategorySelection = () => (
//     <View style={styles.container}>
//       <Text style={styles.title}>{t('diagnosisScreen.whatToDiagnose')}</Text>
//       <TouchableOpacity style={styles.imageCard} onPress={() => handleCategorySelect('cattle')}>
//         <Image source={cattleImage} style={styles.cardImage} resizeMode="cover" />
//         <View style={[styles.cardButton, { backgroundColor: primaryGreen }]}>
//           <Ionicons name="paw-outline" size={24} color={white} />
//           <Text style={styles.cardButtonText}>{t('diagnosisScreen.cattle')}</Text>
//         </View>
//       </TouchableOpacity>
//       <TouchableOpacity style={styles.imageCard} onPress={() => handleCategorySelect('crop')}>
//         <Image source={cropImage} style={styles.cardImage} resizeMode="cover" />
//         <View style={[styles.cardButton, { backgroundColor: primaryGreen }]}>
//           <Ionicons name="leaf-outline" size={24} color={white} />
//           <Text style={styles.cardButtonText}>{t('diagnosisScreen.crop')}</Text>
//         </View>
//       </TouchableOpacity>
//     </View>
//   );

//   const renderDiagnosisMethodSelection = () => (
//     <View style={styles.container}>
//       <Text style={styles.title}>{t('diagnosisScreen.diagnoseVia', {
//         category: selectedCategory === 'cattle' ? t('diagnosisScreen.cattle') : t('diagnosisScreen.crop'),
//       })}</Text>

//       <TouchableOpacity style={styles.methodButton} onPress={() => setSelectedCategory(selectedCategory === 'cattle' ? 'cattle_symptoms' : 'crop_symptoms')}>
//         <Ionicons name="list-outline" size={24} color={primaryBlue} />
//         <Text style={styles.methodButtonText}>{t('diagnosisScreen.enterSymptoms')}</Text>
//       </TouchableOpacity>

//       <TouchableOpacity style={styles.methodButton} onPress={navigateToImageDiagnosis}>
//         <Ionicons name="camera-outline" size={24} color={primaryBlue} />
//         <Text style={styles.methodButtonText}>{t('diagnosisScreen.uploadCaptureImage')}</Text>
//       </TouchableOpacity>

//       <TouchableOpacity style={styles.backButton} onPress={() => setSelectedCategory(null)}>
//         <Ionicons name="arrow-back-circle-outline" size={24} color={darkGray} />
//         <Text style={styles.backButtonText}>{t('diagnosisScreen.backToCategory')}</Text>
//       </TouchableOpacity>
//     </View>
//   );

//   const renderSymptomSelection = () => (
//     <View style={styles.container}>
//       <Text style={styles.title}>{t('diagnosisScreen.selectSymptoms', {
//         category: selectedCategory === 'cattle_symptoms' ? t('diagnosisScreen.cattle') : t('diagnosisScreen.crop'),
//       })}</Text>
//       <ScrollView style={styles.symptomList}>
//         {(selectedCategory === 'cattle_symptoms' ? cattleSymptomsList : cropSymptomsList).map((symptom) => (
//           <TouchableOpacity
//             key={symptom}
//             style={[
//               styles.symptomItem,
//               (selectedCategory === 'cattle_symptoms' ? selectedCattleSymptoms : selectedCropSymptoms).includes(symptom) && styles.selectedSymptom,
//             ]}
//             onPress={() => (selectedCategory === 'cattle_symptoms' ? toggleCattleSymptom(symptom) : toggleCropSymptom(symptom))}
//           >
//             <Ionicons
//               name={(selectedCategory === 'cattle_symptoms' ? selectedCattleSymptoms : selectedCropSymptoms).includes(symptom)
//                 ? 'checkbox-sharp'
//                 : 'square-outline'}
//               size={24}
//               color={primaryBlue}
//               style={styles.checkbox}
//             />
//             <Text style={styles.symptomText}>{symptom}</Text>
//           </TouchableOpacity>
//         ))}
//         <Text style={styles.otherSymptomLabel}>{t('diagnosisScreen.otherSymptoms')}:</Text>
//         <TextInput
//           style={styles.otherSymptomInput}
//           placeholder={t('diagnosisScreen.enterOtherSymptoms', {
//             category: selectedCategory === 'cattle_symptoms' ? t('diagnosisScreen.cattle') : t('diagnosisScreen.crop'),
//           })}
//           value={selectedCategory === 'cattle_symptoms' ? otherCattleSymptom : otherCropSymptom}
//           onChangeText={(text) => selectedCategory === 'cattle_symptoms' ? setOtherCattleSymptom(text) : setOtherCropSymptom(text)}
//         />
//       </ScrollView>
//       <TouchableOpacity style={[styles.submitButton, isDiagnosing && { backgroundColor: darkGray }]} onPress={handleSubmitSymptoms} disabled={isDiagnosing}>
//         <Text style={styles.submitButtonText}>{isDiagnosing ? t('diagnosisScreen.diagnosing') : t('diagnosisScreen.diagnoseButton')}</Text>
//       </TouchableOpacity>
//       <TouchableOpacity style={styles.backButton} onPress={() => setSelectedCategory((selectedCategory?.split('_')[0] as 'cattle' | 'crop') || null)}>
//         <Ionicons name="arrow-back-circle-outline" size={24} color={darkGray} />
//         <Text style={styles.backButtonText}>{t('diagnosisScreen.back')}</Text>
//       </TouchableOpacity>
//       {predictionResult !== '' && (
//         <Text style={styles.predictionResultText}>{predictionResult}</Text>
//       )}
//     </View>
//   );

//   if (!selectedCategory) return renderCategorySelection();
//   if (selectedCategory === 'cattle' || selectedCategory === 'crop') return renderDiagnosisMethodSelection();
//   return renderSymptomSelection();
// };

// const styles = StyleSheet.create({
//   container: { flex: 1, alignItems: 'center', paddingHorizontal: 20, paddingTop: 30, backgroundColor: lightBlueBackground },
//   title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: darkGray, textAlign: 'center' },
//   imageCard: { width: '90%', borderRadius: 15, marginBottom: 15, overflow: 'hidden', backgroundColor: white, elevation: 5 },
//   cardImage: { width: '100%', height: 140 },
//   cardButton: { paddingVertical: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
//   cardButtonText: { color: white, fontSize: 18, fontWeight: 'bold', marginLeft: 8 },
//   methodButton: {
//     flexDirection: 'row', alignItems: 'center', backgroundColor: secondaryYellow,
//     paddingVertical: 15, paddingHorizontal: 30, borderRadius: 10, marginBottom: 15,
//     elevation: 2, width: '80%', justifyContent: 'center',
//   },
//   methodButtonText: { fontSize: 18, color: darkGray, marginLeft: 15 },
//   symptomList: { marginBottom: 20, width: '90%' },
//   symptomItem: {
//     flexDirection: 'row', alignItems: 'center', paddingVertical: 12,
//     paddingHorizontal: 15, borderRadius: 8, borderWidth: 1, borderColor: '#ccc',
//     marginBottom: 10,
//   },
//   selectedSymptom: { backgroundColor: '#E1F5FE', borderColor: primaryBlue },
//   checkbox: { marginRight: 15 },
//   symptomText: { fontSize: 16, color: darkGray },
//   submitButton: {
//     backgroundColor: primaryBlue, paddingVertical: 15, borderRadius: 10,
//     alignItems: 'center', marginBottom: 10, width: '80%',
//   },
//   submitButtonText: { color: white, fontSize: 18, fontWeight: 'bold' },
//   backButton: { flexDirection: 'row', alignItems: 'center', marginTop: 20 },
//   backButtonText: { fontSize: 16, color: darkGray, marginLeft: 8 },
//   otherSymptomLabel: { fontSize: 16, color: darkGray, marginTop: 15, marginBottom: 5, alignSelf: 'flex-start' },
//   otherSymptomInput: {
//     height: 40, borderColor: inputBorderColor, borderWidth: 1, borderRadius: 8,
//     backgroundColor: inputBackgroundColor, paddingHorizontal: 10, marginBottom: 15, width: '100%',
//   },
//   predictionResultText: { marginTop: 20, fontSize: 18, fontWeight: 'bold', color: primaryBlue, textAlign: 'center' },
// });

// export default DiagnosisScreen;

// diagnosis.tsx



// diagnosis.tsx
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, TextInput, Image, Alert, StyleSheet
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import * as ImagePicker from 'expo-image-picker';
import { auth, db } from '../../../firebaseConfig';
import { collection, addDoc } from 'firebase/firestore';

import cattleImage from '../../../assets/images/cattlediagnose.jpg';
import cropImage from '../../../assets/images/cropdiagnose.jpg';

const primaryGreen = '#81C784';
const secondaryYellow = '#FFF59D';
const primaryBlue = '#64B5F6';
const white = '#FFFFFF';
const darkGray = '#333';
const inputBackgroundColor = '#F5F5F5';
const inputBorderColor = '#E0E0E0';
const lightBlueBackground = '#D1E9FF';

const DiagnosisScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCattleSymptoms, setSelectedCattleSymptoms] = useState<string[]>([]);
  const [selectedCropSymptoms, setSelectedCropSymptoms] = useState<string[]>([]);
  const [otherCattleSymptom, setOtherCattleSymptom] = useState('');
  const [otherCropSymptom, setOtherCropSymptom] = useState('');
  const [predictionResult, setPredictionResult] = useState('');
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const { t } = useTranslation();

  const cattleSymptomsList = ['Loss of appetite', 'Fever', 'Coughing', 'Skin lesions', 'Lameness'];
  const cropSymptomsList = ['Wilting', 'Yellowing leaves', 'Stunted growth', 'Spots on leaves', 'Root rot'];

  const toggleSymptom = (symptom: string, isCattle: boolean) => {
    const list = isCattle ? selectedCattleSymptoms : selectedCropSymptoms;
    const setter = isCattle ? setSelectedCattleSymptoms : setSelectedCropSymptoms;
    setter(list.includes(symptom) ? list.filter(s => s !== symptom) : [...list, symptom]);
  };

  const handleSubmitSymptoms = async () => {
    let allSymptoms: string[] = [];
    let type = '';
    if (selectedCategory === 'cattle_symptoms') {
      allSymptoms = [...selectedCattleSymptoms];
      if (otherCattleSymptom.trim()) allSymptoms.push(otherCattleSymptom.trim());
      type = 'Cattle';
    } else {
      allSymptoms = [...selectedCropSymptoms];
      if (otherCropSymptom.trim()) allSymptoms.push(otherCropSymptom.trim());
      type = 'Crop';
    }

    try {
      setIsDiagnosing(true);
      const response = await axios.post('http://10.205.30.233:5000/predict', {
        symptoms: allSymptoms.join(', ')
      });
      const { disease } = response.data;
      setPredictionResult(`Predicted Disease: ${disease}`);
      await saveReportToFirebase(type, disease, 'Symptoms');
      Alert.alert('Diagnosis Result', `Predicted Disease: ${disease}`);
    } catch (e) {
      Alert.alert('Error', 'Diagnosis failed. Please try again.');
    } finally {
      setIsDiagnosing(false);
    }
  };

  const navigateToImageDiagnosis = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Permission denied', 'Camera roll permissions are required.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 1,
      });

      if (!result.canceled && result.assets.length > 0) {
        const image = result.assets[0];
        const formData = new FormData();
        formData.append('image', {
          uri: image.uri,
          name: 'diagnosis.jpg',
          type: 'image/jpeg',
        } as any);

        setIsDiagnosing(true);
        const response = await axios.post('http://10.205.30.233:5001/predict', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });

        const { disease } = response.data;
        setPredictionResult(`Predicted Disease: ${disease}`);
        await saveReportToFirebase(selectedCategory ?? '', disease, 'Image');
        Alert.alert('Diagnosis Result', `Predicted Disease: ${disease}`);
      }
    } catch (e) {
      Alert.alert('Error', 'Image diagnosis failed. Please try again.');
    } finally {
      setIsDiagnosing(false);
    }
  };

  const saveReportToFirebase = async (category: string, disease: string, diagnosisType: string) => {
    try {
      await addDoc(collection(db, 'diagnosis_reports'), {
        category,
        disease,
        diagnosisType,
        timestamp: new Date(),
      });
    } catch (e) {
      console.error('Firebase error:', e);
    }
  };

  const renderCategorySelection = () => (
    <View style={styles.container}>
      <Text style={styles.title}>What do you want to diagnose?</Text>
      <TouchableOpacity style={styles.imageCard} onPress={() => setSelectedCategory('cattle')}>
        <Image source={cattleImage} style={styles.cardImage} />
        <View style={[styles.cardButton, { backgroundColor: primaryGreen }]}>
          <Ionicons name="paw-outline" size={24} color={white} />
          <Text style={styles.cardButtonText}>Cattle</Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity style={styles.imageCard} onPress={() => setSelectedCategory('crop')}>
        <Image source={cropImage} style={styles.cardImage} />
        <View style={[styles.cardButton, { backgroundColor: primaryGreen }]}>
          <Ionicons name="leaf-outline" size={24} color={white} />
          <Text style={styles.cardButtonText}>Crop</Text>
        </View>
      </TouchableOpacity>
    </View>
  );

  const renderDiagnosisMethodSelection = () => (
    <View style={styles.container}>
      <Text style={styles.title}>Diagnose via:</Text>
      <TouchableOpacity
        style={styles.methodButton}
        onPress={() => setSelectedCategory(`${selectedCategory}_symptoms`)}>
        <Ionicons name="list-outline" size={24} color={primaryBlue} />
        <Text style={styles.methodButtonText}>Enter Symptoms</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.methodButton} onPress={navigateToImageDiagnosis}>
        <Ionicons name="camera-outline" size={24} color={primaryBlue} />
        <Text style={styles.methodButtonText}>Upload/Capture Image</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.backButton} onPress={() => setSelectedCategory(null)}>
        <Ionicons name="arrow-back-circle-outline" size={24} color={darkGray} />
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>
    </View>
  );

  const renderSymptomSelection = () => {
    const isCattle = selectedCategory === 'cattle_symptoms';
    const symptomList = isCattle ? cattleSymptomsList : cropSymptomsList;
    const selectedSymptoms = isCattle ? selectedCattleSymptoms : selectedCropSymptoms;
    const otherSymptom = isCattle ? otherCattleSymptom : otherCropSymptom;

    return (
      <View style={styles.container}>
        <Text style={styles.title}>Select Symptoms</Text>
        <ScrollView style={styles.symptomList}>
          {symptomList.map((symptom) => (
            <TouchableOpacity
              key={symptom}
              style={[
                styles.symptomItem,
                selectedSymptoms.includes(symptom) && styles.selectedSymptom,
              ]}
              onPress={() => toggleSymptom(symptom, isCattle)}>
              <Ionicons
                name={selectedSymptoms.includes(symptom) ? 'checkbox-sharp' : 'square-outline'}
                size={24}
                color={primaryBlue}
                style={styles.checkbox}
              />
              <Text style={styles.symptomText}>{symptom}</Text>
            </TouchableOpacity>
          ))}
          <TextInput
            style={styles.otherSymptomInput}
            placeholder="Enter other symptoms"
            value={otherSymptom}
            onChangeText={(text) =>
              isCattle ? setOtherCattleSymptom(text) : setOtherCropSymptom(text)
            }
          />
        </ScrollView>
        <TouchableOpacity
          style={[styles.submitButton, isDiagnosing && { backgroundColor: darkGray }]}
          onPress={handleSubmitSymptoms}
          disabled={isDiagnosing}>
          <Text style={styles.submitButtonText}>
            {isDiagnosing ? 'Diagnosing...' : 'Diagnose'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setSelectedCategory(isCattle ? 'cattle' : 'crop')}>
          <Ionicons name="arrow-back-circle-outline" size={24} color={darkGray} />
          <Text style={styles.backButtonText}>Back</Text>
        </TouchableOpacity>
        {predictionResult && <Text style={styles.predictionResultText}>{predictionResult}</Text>}
      </View>
    );
  };

  if (!selectedCategory) return renderCategorySelection();
  if (selectedCategory === 'cattle' || selectedCategory === 'crop') return renderDiagnosisMethodSelection();
  return renderSymptomSelection();
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', padding: 20, backgroundColor: lightBlueBackground },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: darkGray, textAlign: 'center' },
  imageCard: { width: '90%', borderRadius: 15, marginBottom: 15, backgroundColor: white, elevation: 5 },
  cardImage: { width: '100%', height: 140 },
  cardButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14 },
  cardButtonText: { color: white, fontSize: 18, fontWeight: 'bold', marginLeft: 8 },
  methodButton: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: secondaryYellow,
    padding: 15, borderRadius: 10, marginBottom: 15, width: '80%', justifyContent: 'center',
  },
  methodButtonText: { fontSize: 18, color: darkGray, marginLeft: 15 },
  symptomList: { marginBottom: 20, width: '100%' },
  symptomItem: {
    flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 8,
    borderWidth: 1, borderColor: '#ccc', marginBottom: 10,
  },
  selectedSymptom: { backgroundColor: '#E1F5FE', borderColor: primaryBlue },
  checkbox: { marginRight: 15 },
  symptomText: { fontSize: 16, color: darkGray },
  otherSymptomInput: {
    height: 40, borderColor: inputBorderColor, borderWidth: 1, borderRadius: 8,
    backgroundColor: inputBackgroundColor, paddingHorizontal: 10, marginBottom: 15, width: '100%',
  },
  submitButton: {
    backgroundColor: primaryBlue, padding: 15, borderRadius: 10,
    alignItems: 'center', marginBottom: 10, width: '80%',
  },
  submitButtonText: { color: white, fontSize: 18, fontWeight: 'bold' },
  backButton: { flexDirection: 'row', alignItems: 'center', marginTop: 20 },
  backButtonText: { fontSize: 16, color: darkGray, marginLeft: 8 },
  predictionResultText: { marginTop: 20, fontSize: 18, fontWeight: 'bold', color: primaryBlue, textAlign: 'center' },
});

export default DiagnosisScreen;
